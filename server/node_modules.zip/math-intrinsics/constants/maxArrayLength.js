'use strict';

/** @type {import('./maxArrayLength')} */
module.exports = 4294967295; // Math.pow(2, 32) - 1;
