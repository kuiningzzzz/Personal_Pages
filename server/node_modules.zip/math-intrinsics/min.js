'use strict';

/** @type {import('./min')} */
module.exports = Math.min;
